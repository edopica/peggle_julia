# Benchmark Run: `deathstar-20261027-scoring-baseline`

- **Benchmark**: `ribbon_1v1_campaign`
- **Workload**: `ribbon_1v1_10matches_1801aim`
- **Status**: `completed`
- **Timestamp (UTC)**: `2026-10-27T15:47:15Z`
- **Host**: `deathstar` (`AMD Ryzen Threadripper 2990WX 32-Core Processor`, 8 physical cores / 64 threads)
- **Runtime**: Julia `1.12.6` with `1` threads
- **Git revision**: `be7856a48a44485caeaa222420a701d1423d4c20` (dirty: `False`)
- **Harness fingerprint**: `461e02e10547a119dd25c7b4d21c7ecddca76438a2398423cdbfbccfbaa5631b`
- **Canonical gameplay hash**: `82b282ee176746817047e93d90755bedae81de07ed3b5ed876c9c336c8a96bb3`

## Worker Scaling

Summary metrics (medians across 1 repetition(s) per worker count):

| Workers | Campaign wall (s) | Completed matches/hour | Candidates/second | Speedup | Efficiency |
| ---: | ---: | ---: | ---: | ---: | ---: |
| 1 | 211.167 | 170.5 | 938.2 | 1.00× | 100.0% |

### Wall Time by Repeat

| Workers | Repeat 1 (s) |
| ---: | ---: |
| 1 | 211.167 |

### Decision Latencies

| Workers | Mean decision (s) | p50 decision (s) | p95 decision (s) | Verification/output (s) |
| ---: | ---: | ---: | ---: | ---: |
| 1 | 1.919 | 0.869 | 6.914 | 0.0388 |

### Phase Durations

Values are summed worker wall durations across all matches:

| Workers | Simulation (s) | Candidate reset (s) | Selection (ms) | Actual shot (ms) | Checkpoint (ms) |
| ---: | ---: | ---: | ---: | ---: | ---: |
| 1 | 209.268 | 1.622 | 10.437 | 202.910 | 10.685 |

Process RSS after output ranges from **604.3 to 604.3 MiB**.
Cumulative process peak RSS is **677.1 MiB**.

## Match Results

Seeded matches (10 matches per campaign, 1 trials, all completed):

| Match | Player 1 score | Player 2 score | Winner | Turns | Termination |
| --- | ---: | ---: | ---: | ---: | --- |
| 1 | 128,460 | 146,250 | 2 | 7 | all_red_cleared |
| 2 | 248,840 | 149,963 | 1 | 10 | all_red_cleared |
| 3 | 140,770 | 325,590 | 2 | 8 | all_red_cleared |
| 4 | 233,364 | 117,240 | 1 | 9 | all_red_cleared |
| 5 | 210,860 | 308,470 | 2 | 6 | all_red_cleared |
| 6 | 839,728 | 71,650 | 1 | 11 | all_red_cleared |
| 7 | 31,533 | 7,608 | 1 | 20 | balls_exhausted |
| 8 | 104,580 | 289,420 | 2 | 8 | all_red_cleared |
| 9 | 19,643 | 273,763 | 2 | 12 | all_red_cleared |
| 10 | 308,970 | 39,771 | 1 | 19 | all_red_cleared |

## Workload Configuration

- Mode: `1v1`
- Matches: `10`
- Base seed: `20261024`
- Candidates per turn: `1801`
- Level: `fixtures/ribbon_waves/artifact/ribbon_waves.v1.json` (`073b426e66c948895a73a5a45b96b4a5538332c8db2d5b1318f245f8ffe6f86e`)
- Config: `campaigns/ribbon/config.v1.json` (`9de96e70851daa3d596c9cd3e28a1ad67705ec70e4afda5090e6868a2cad385c`)


## Artifacts

- Canonical gameplay history: [`../results/benchmarks/histories/82b282ee176746817047e93d90755bedae81de07ed3b5ed876c9c336c8a96bb3.json`](<../../../../../results/benchmarks/histories/82b282ee176746817047e93d90755bedae81de07ed3b5ed876c9c336c8a96bb3.json>)
- Full archive bundle: [`../results/benchmarks/artifacts/deathstar-20261027-scoring-baseline.tar.gz`](<../../../../../results/benchmarks/artifacts/deathstar-20261027-scoring-baseline.tar.gz>)

#!/usr/bin/env bash
set -euo pipefail
job=/home/picazio/projects/peggle-benchmarks/scoring-20261027
resume="$job/resume-01"
export PATH=/home/picazio/projects/peggle-benchmarks/tools/bin:$PATH
export JULIA_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 PEGGLE_MATH_BACKEND=system_libm
mkdir "$resume"
finish() {
  result=$?
  trap - EXIT
  echo "$result" > "$resume/exit-code"
  date -u +%FT%TZ > "$resume/finished-at"
  if test "$result" -eq 0; then echo completed; else echo failed; fi > "$resume/status"
  exit "$result"
}
trap finish EXIT
date -u +%FT%TZ > "$resume/started-at"
echo preflight > "$resume/status"
cd "$job/candidate"
uptime > "$resume/host-before.txt"
ps -eo pid,pcpu,args --sort=-pcpu > "$resume/processes-before.txt"
make verify > "$resume/reference-before.log" 2>&1
python3 "$job/py310_runner.py" scripts/validate_benchmark.py "$job/results/benchmarks/runs/deathstar-20261027-scoring-baseline" > "$resume/baseline-validation.log" 2>&1
echo benchmarking-candidate > "$resume/status"
julia --project=julia/PeggleSim scripts/run_campaign_benchmark.jl \
  --run-id deathstar-20261027-scoring-candidate \
  --benchmarks-dir tmp/scoring-benchmarks --allow-dirty \
  --worker-counts 1 --threads 1 --games 10 --repeats 1 \
  --warmup full --mode 1v1 --base-seed 20261024 \
  --workload-id ribbon_1v1_10matches_1801aim > "$resume/candidate-benchmark.log" 2>&1
echo postflight > "$resume/status"
make verify > "$resume/reference-after.log" 2>&1
python3 "$job/py310_runner.py" scripts/validate_benchmark.py tmp/scoring-benchmarks/runs/deathstar-20261027-scoring-candidate --index tmp/scoring-benchmarks/index.csv > "$resume/candidate-validation.log" 2>&1
python3 "$job/py310_runner.py" scripts/compare_benchmarks.py \
  "$job/results/benchmarks/runs/deathstar-20261027-scoring-baseline" \
  tmp/scoring-benchmarks/runs/deathstar-20261027-scoring-candidate > "$resume/comparison.txt" 2>&1
uptime > "$resume/host-after.txt"

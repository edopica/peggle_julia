#!/usr/bin/env bash
set -euo pipefail

job_dir=/home/picazio/projects/peggle-benchmarks/scoring-20261027
benchmarks_dir="$job_dir/results/benchmarks"
baseline_id=deathstar-20261027-scoring-baseline
candidate_id=deathstar-20261027-scoring-candidate
export PATH=/home/picazio/projects/peggle-benchmarks/tools/bin:$PATH
export JULIA_NUM_THREADS=1
export JULIA_NUM_PRECOMPILE_TASKS=4
export OPENBLAS_NUM_THREADS=1
export OMP_NUM_THREADS=1
export PEGGLE_MATH_BACKEND=system_libm

cd "$job_dir"
test ! -e started-at
test ! -e exit-code
test "$(hostname -s)" = deathstar
finish() {
    result=$?
    trap - EXIT
    printf '%s\n' "$result" > "$job_dir/exit-code"
    date -u +%FT%TZ > "$job_dir/finished-at"
    if [ "$result" -eq 0 ]; then
        printf 'completed\n' > "$job_dir/status"
    else
        printf 'failed\n' > "$job_dir/status"
    fi
    exit "$result"
}
trap finish EXIT
date -u +%FT%TZ > started-at
printf 'preflight\n' > status
printf '%s\n' "PATH=$PATH" "JULIA_NUM_THREADS=$JULIA_NUM_THREADS" \
    "JULIA_NUM_PRECOMPILE_TASKS=$JULIA_NUM_PRECOMPILE_TASKS" \
    "OPENBLAS_NUM_THREADS=$OPENBLAS_NUM_THREADS" "OMP_NUM_THREADS=$OMP_NUM_THREADS" \
    "PEGGLE_MATH_BACKEND=$PEGGLE_MATH_BACKEND" > environment.txt
julia --version > runtime.txt
luajit -v >> runtime.txt 2>&1
uptime > host-before.txt
free -h >> host-before.txt
lscpu >> host-before.txt
ps -eo pid,pcpu,args --sort=-pcpu > processes-before.txt

# Validate both variants before any timing so candidate failures cannot waste
# the baseline campaign. Logs and benchmark artifacts stay outside checkouts.
for variant in baseline candidate; do
    printf 'preflight-%s\n' "$variant" > "$job_dir/status"
    cd "$job_dir/$variant"
    git rev-parse HEAD > "$job_dir/$variant-revision"
    git status --porcelain > "$job_dir/$variant-source-status.txt"
    git diff --binary HEAD > "$job_dir/$variant.patch"
    if [ "$variant" = baseline ]; then
        test -z "$(git status --porcelain)"
    fi
    julia --project=julia/PeggleSim -e 'using Pkg; Pkg.instantiate(); using PeggleSim' \
        > "$job_dir/$variant-instantiate.log" 2>&1
    make verify > "$job_dir/$variant-reference-before.log" 2>&1
    julia --project=julia/PeggleSim scripts/sync_campaign_config.jl --check \
        > "$job_dir/$variant-config-check.log" 2>&1
    julia --project=julia/PeggleSim julia/PeggleSim/test/runtests.jl \
        > "$job_dir/$variant-simulator-tests.log" 2>&1
done

for variant in baseline candidate; do
    printf 'benchmarking-%s\n' "$variant" > "$job_dir/status"
    cd "$job_dir/$variant"
    run_id="$baseline_id"
    extra_args=()
    if [ "$variant" = candidate ]; then
        run_id="$candidate_id"
        extra_args+=(--allow-dirty)
    fi
    date -u +%FT%TZ > "$job_dir/$variant-started-at"
    uptime > "$job_dir/$variant-host-before.txt"
    ps -eo pid,pcpu,args --sort=-pcpu > "$job_dir/$variant-processes-before.txt"
    julia --project=julia/PeggleSim scripts/run_campaign_benchmark.jl \
        --run-id "$run_id" --benchmarks-dir "$benchmarks_dir" \
        --worker-counts 1 --threads 1 --games 10 --repeats 1 \
        --warmup full --mode 1v1 --base-seed 20261024 \
        --workload-id ribbon_1v1_10matches_1801aim "${extra_args[@]}" \
        > "$job_dir/$variant-benchmark.log" 2>&1
    printf 'postflight-%s\n' "$variant" > "$job_dir/status"
    make verify > "$job_dir/$variant-reference-after.log" 2>&1
    python3 "$job_dir/py310_runner.py" scripts/validate_benchmark.py "$benchmarks_dir/runs/$run_id" \
        --index "$benchmarks_dir/index.csv" > "$job_dir/$variant-validation.log" 2>&1
    date -u +%FT%TZ > "$job_dir/$variant-finished-at"
done

printf 'comparing\n' > "$job_dir/status"
cd "$job_dir/candidate"
# This verifies source/run compatibility and checks both canonical history files
# byte-for-byte, in addition to reporting wall time and throughput ratios.
python3 "$job_dir/py310_runner.py" scripts/compare_benchmarks.py "$baseline_id" "$candidate_id" \
    --benchmarks-dir "$benchmarks_dir" > "$job_dir/comparison.txt" 2>&1
uptime > "$job_dir/host-after.txt"
free -h >> "$job_dir/host-after.txt"
ps -eo pid,pcpu,args --sort=-pcpu > "$job_dir/processes-after.txt"

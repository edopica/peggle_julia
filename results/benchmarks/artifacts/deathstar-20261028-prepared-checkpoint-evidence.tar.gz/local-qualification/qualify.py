import hashlib
import json
from pathlib import Path
import subprocess

root = Path('tmp/compact-checkpoint')
rows = []
subprocess.run(['make', 'verify'], check=True, stdout=(root/'reference-before.log').open('w'))
workloads = [('overhead_static_2p','long_shot',1), ('circles_small','circle_level',1),
             ('circles_mixed','off_the_wall',1), ('lines_rect_annular','slide',1),
             ('annular_dense','squiggly_circle',1), ('annular_dense_multi3','squiggly_circle',3),
             ('lines_rect_annular_multi3','slide',3)]
for name,level,balls in workloads:
    for threads in ([1,2,4] if name in ('lines_rect_annular','annular_dense') else [1]):
        output = root/f'm4-julia-{name}-t{threads}.jsonl'
        command = ['julia','--project=julia/PeggleSim','-t',str(threads),
            'julia/PeggleSim/bin/shot_bench.jl','--sweep','--prepared',
            '--level',f'interchange/levels/{level}.v1.json','--config','interchange/config.v1.json',
            '--balls',str(balls),'--stride','1','--threads',str(threads),'--verify-serial',
            '--out',str(output),'--summary',str(output.with_suffix('.json'))]
        with output.with_suffix('.log').open('w') as log:
            subprocess.run(command,check=True,stdout=log,stderr=subprocess.STDOUT)
        baseline = Path('tmp/static-query-optimization/m4-raw')/output.name
        assert output.read_bytes()==baseline.read_bytes(),name
        data=[json.loads(s) for s in output.read_text().splitlines()]
        assert len(data)==1801 and all(x['completed'] for x in data)
        assert [x['index'] for x in data]==list(range(1801))
        assert output.read_bytes()==(root/f'm4-julia-{name}-t1.jsonl').read_bytes()
        rows.append(dict(workload=name,threads=threads,rows=1801,byte_identical_to_retained_baseline=True,
                         sha256=hashlib.sha256(output.read_bytes()).hexdigest(),command=command))
        print(name,threads,'PASS',flush=True)
subprocess.run(['make','verify'],check=True,stdout=(root/'reference-after.log').open('w'))
(root/'sweep-qualification.json').write_text(json.dumps(dict(passed=True,sweeps=rows),indent=2)+'\n')

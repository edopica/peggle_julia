#!/usr/bin/env bash
set -euo pipefail
job=/home/picazio/projects/peggle-benchmarks/compact-checkpoint-20261028-02
export PATH=/home/picazio/projects/peggle-benchmarks/tools/bin:$PATH
export JULIA_NUM_PRECOMPILE_TASKS=4 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 PEGGLE_MATH_BACKEND=system_libm
cd "$job"
test ! -e started-at
finish() {
  code=$?
  trap - EXIT
  echo "$code" > exit-code
  date -u +%FT%TZ > finished-at
  exit "$code"
}
trap finish EXIT
date -u +%FT%TZ > started-at
echo preflight > status
hostname > host.txt
uptime >> host.txt
lscpu >> host.txt
free -h >> host.txt
ps -eo pid,pcpu,args --sort=-pcpu > processes-before.txt
julia --version > runtime.txt
for variant in baseline prepared compact; do
  (cd "$variant" && make verify) > "verify-before-$variant.log" 2>&1
done
cd compact
julia --startup-file=no --project=julia/PeggleSim -t 4,0 --gcthreads=1 \
  julia/PeggleSim/test/test_prepared_checkpoint.jl > "$job/tests.log" 2>&1
echo benchmarking > "$job/status"
uptime > "$job/trial-host-before.txt"
ps -eo pid,pcpu,args --sort=-pcpu > "$job/trial-processes-before.txt"
julia --startup-file=no --project=julia/PeggleSim -t 8,0 --gcthreads=1 \
  scripts/bench_prepared_checkpoint.jl "$job/baseline" "$job/prepared" "$job/measurements" 8 3 \
  > "$job/benchmark.log" 2>&1
cd "$job"
echo postflight > status
for variant in baseline prepared compact; do
  (cd "$variant" && make verify) > "verify-after-$variant.log" 2>&1
done
python3 - <<'PY'
import hashlib, json
from pathlib import Path
expected=json.loads(Path('source-hashes.json').read_text())
for variant,files in expected.items():
    for file,witness in files.items():
        assert hashlib.sha256((Path(variant)/file).read_bytes()).hexdigest()==witness,(variant,file)
histories=list(Path('measurements').glob('history-*.json'))
assert len(histories)==9
data=histories[0].read_bytes()
assert all(p.read_bytes()==data for p in histories)
previous=list(Path('/home/picazio/projects/peggle-benchmarks/static-query-20261027/source/tmp/static-query-benchmarks/histories').glob('*.json'))
assert len(previous)==1
assert previous[0].read_bytes()==data
Path('checks.json').write_text(json.dumps(dict(source_hashes_unchanged=True,all_nine_histories_byte_identical=True,historical_gameplay_byte_identical=True,gameplay_sha256=hashlib.sha256(data).hexdigest()),indent=2)+'\n')
PY
uptime > host-after.txt
ps -eo pid,pcpu,args --sort=-pcpu > processes-after.txt
echo completed > status

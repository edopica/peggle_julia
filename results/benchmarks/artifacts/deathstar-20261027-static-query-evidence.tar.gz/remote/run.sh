#!/usr/bin/env bash
set -euo pipefail
job=/home/picazio/projects/peggle-benchmarks/static-query-20261027
old=/home/picazio/projects/peggle-benchmarks/scoring-20261027
export PATH=/home/picazio/projects/peggle-benchmarks/tools/bin:$PATH
export JULIA_NUM_THREADS=1 JULIA_NUM_PRECOMPILE_TASKS=4 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 PEGGLE_MATH_BACKEND=system_libm
cd "$job"
test ! -e started-at
finish() {
  result=$?
  trap - EXIT
  echo "$result" > "$job/exit-code"
  date -u +%FT%TZ > "$job/finished-at"
  if test "$result" -eq 0; then echo completed; else echo failed; fi > "$job/status"
  exit "$result"
}
trap finish EXIT
date -u +%FT%TZ > started-at
echo preflight > status
julia --version > runtime.txt
luajit -v >> runtime.txt 2>&1
env | sort | rg '^(JULIA|OPENBLAS|OMP|PEGGLE|PATH)=' > environment.txt || true
uptime > host-before.txt
free -h >> host-before.txt
lscpu >> host-before.txt
ps -eo pid,pcpu,args --sort=-pcpu > processes-before.txt
cd source
git rev-parse HEAD > "$job/revision"
git status --porcelain > "$job/source-status.txt"
git diff --binary HEAD > "$job/source.patch"
julia --project=julia/PeggleSim -e 'using Pkg; Pkg.instantiate(); using PeggleSim' > "$job/instantiate.log" 2>&1
make verify > "$job/reference-before.log" 2>&1
julia --project=julia/PeggleSim scripts/sync_campaign_config.jl --check > "$job/config-check.log" 2>&1
julia --project=julia/PeggleSim julia/PeggleSim/test/runtests.jl > "$job/simulator-tests.log" 2>&1
# Preserve original root-relative artifact paths when comparing the saved baseline.
mkdir -p tmp
cp -a "$old/candidate/tmp/scoring-benchmarks" tmp/scoring-benchmarks
python3 "$job/py310_runner.py" scripts/validate_benchmark.py tmp/scoring-benchmarks/runs/deathstar-20261027-scoring-candidate --index tmp/scoring-benchmarks/index.csv > "$job/baseline-validation.log" 2>&1
echo benchmarking > "$job/status"
uptime > "$job/trial-host-before.txt"
ps -eo pid,pcpu,args --sort=-pcpu > "$job/trial-processes-before.txt"
julia --project=julia/PeggleSim scripts/run_campaign_benchmark.jl \
 --run-id deathstar-20261027-static-query-candidate \
 --benchmarks-dir tmp/static-query-benchmarks --allow-dirty \
 --worker-counts 1 --threads 1 --games 10 --repeats 1 \
 --warmup full --mode 1v1 --base-seed 20261024 \
 --workload-id ribbon_1v1_10matches_1801aim > "$job/benchmark.log" 2>&1
echo postflight > "$job/status"
make verify > "$job/reference-after.log" 2>&1
python3 "$job/py310_runner.py" scripts/validate_benchmark.py tmp/static-query-benchmarks/runs/deathstar-20261027-static-query-candidate --index tmp/static-query-benchmarks/index.csv > "$job/candidate-validation.log" 2>&1
python3 "$job/py310_runner.py" scripts/compare_benchmarks.py tmp/scoring-benchmarks/runs/deathstar-20261027-scoring-candidate tmp/static-query-benchmarks/runs/deathstar-20261027-static-query-candidate > "$job/comparison.txt" 2>&1
uptime > "$job/host-after.txt"
ps -eo pid,pcpu,args --sort=-pcpu > "$job/processes-after.txt"

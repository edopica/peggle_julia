# Benchmark Run: `deathstar-20261027-static-query-candidate`

- **Benchmark**: `ribbon_1v1_campaign`
- **Workload**: `ribbon_1v1_10matches_1801aim`
- **Status**: `completed`
- **Timestamp (UTC)**: `2026-10-27T20:45:11Z`
- **Host**: `deathstar` (`AMD Ryzen Threadripper 2990WX 32-Core Processor`, 8 physical cores / 64 threads)
- **Runtime**: Julia `1.12.6` with `1` threads
- **Git revision**: `fd760fc6161ea006ba12c14ba22484fbcd90f96c` (dirty: `True`)
- **Harness fingerprint**: `12472f99ef45b61d99d6c26a4aee63c8418cbe48e3097a7a898f6b3a1b820bc1`
- **Canonical gameplay hash**: `82b282ee176746817047e93d90755bedae81de07ed3b5ed876c9c336c8a96bb3`

## Worker Scaling

Summary metrics (medians across 1 repetition(s) per worker count):

| Workers | Campaign wall (s) | Completed matches/hour | Candidates/second | Speedup | Efficiency |
| ---: | ---: | ---: | ---: | ---: | ---: |
| 1 | 145.948 | 246.7 | 1,357.4 | 1.00× | 100.0% |

### Wall Time by Repeat

| Workers | Repeat 1 (s) |
| ---: | ---: |
| 1 | 145.948 |

### Decision Latencies

| Workers | Mean decision (s) | p50 decision (s) | p95 decision (s) | Verification/output (s) |
| ---: | ---: | ---: | ---: | ---: |
| 1 | 1.326 | 0.564 | 4.908 | 0.0389 |

### Phase Durations

Values are summed worker wall durations across all matches:

| Workers | Simulation (s) | Candidate reset (s) | Selection (ms) | Actual shot (ms) | Checkpoint (ms) |
| ---: | ---: | ---: | ---: | ---: | ---: |
| 1 | 144.234 | 1.498 | 8.687 | 144.142 | 10.854 |

Process RSS after output ranges from **596.6 to 596.6 MiB**.
Cumulative process peak RSS is **640.7 MiB**.

## Match Results

Seeded matches (10 matches per campaign, 1 trials, all completed):

| Match | Player 1 score | Player 2 score | Winner | Turns | Termination |
| --- | ---: | ---: | ---: | ---: | --- |
| 1 | 128,460 | 146,250 | 2 | 7 | all_red_cleared |
| 2 | 248,840 | 149,963 | 1 | 10 | all_red_cleared |
| 3 | 140,770 | 325,590 | 2 | 8 | all_red_cleared |
| 4 | 233,364 | 117,240 | 1 | 9 | all_red_cleared |
| 5 | 210,860 | 308,470 | 2 | 6 | all_red_cleared |
| 6 | 839,728 | 71,650 | 1 | 11 | all_red_cleared |
| 7 | 31,533 | 7,608 | 1 | 20 | balls_exhausted |
| 8 | 104,580 | 289,420 | 2 | 8 | all_red_cleared |
| 9 | 19,643 | 273,763 | 2 | 12 | all_red_cleared |
| 10 | 308,970 | 39,771 | 1 | 19 | all_red_cleared |

## Workload Configuration

- Mode: `1v1`
- Matches: `10`
- Base seed: `20261024`
- Candidates per turn: `1801`
- Level: `fixtures/ribbon_waves/artifact/ribbon_waves.v1.json` (`073b426e66c948895a73a5a45b96b4a5538332c8db2d5b1318f245f8ffe6f86e`)
- Config: `campaigns/ribbon/config.v1.json` (`9de96e70851daa3d596c9cd3e28a1ad67705ec70e4afda5090e6868a2cad385c`)


## Artifacts

- Canonical gameplay history: [`tmp/static-query-benchmarks/histories/82b282ee176746817047e93d90755bedae81de07ed3b5ed876c9c336c8a96bb3.json`](<../../../../tmp/static-query-benchmarks/histories/82b282ee176746817047e93d90755bedae81de07ed3b5ed876c9c336c8a96bb3.json>)
- Full archive bundle: [`tmp/static-query-benchmarks/artifacts/deathstar-20261027-static-query-candidate.tar.gz`](<../../../../tmp/static-query-benchmarks/artifacts/deathstar-20261027-static-query-candidate.tar.gz>)

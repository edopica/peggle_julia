from pathlib import Path
import hashlib
import json
import subprocess
import sys

root = Path('tmp/static-query-optimization')
new_dir = root / 'm4-raw'
baseline_dir = Path('tmp/scoring-optimization/m4-raw')
workloads = ('overhead_static_2p', 'circles_small', 'circles_mixed',
             'lines_rect_annular', 'annular_dense', 'annular_dense_multi3',
             'lines_rect_annular_multi3')
comparisons = []
lua_reports = []
for name in workloads:
    threads = (1, 2, 4) if name in ('lines_rect_annular', 'annular_dense') else (1,)
    for thread in threads:
        filename = f'm4-julia-{name}-t{thread}.jsonl'
        baseline = baseline_dir / filename
        candidate = new_dir / filename
        old_bytes, new_bytes = baseline.read_bytes(), candidate.read_bytes()
        rows = [json.loads(line) for line in new_bytes.splitlines() if line.strip()]
        matches_t1 = new_bytes == (new_dir / f'm4-julia-{name}-t1.jsonl').read_bytes()
        comparisons.append(dict(workload=name, threads=thread,
            baseline=str(baseline), candidate=str(candidate),
            baseline_sha256=hashlib.sha256(old_bytes).hexdigest(),
            candidate_sha256=hashlib.sha256(new_bytes).hexdigest(),
            byte_identical=old_bytes == new_bytes, row_count=len(rows),
            all_completed=all(row['completed'] for row in rows),
            thread_identity=matches_t1,
            aim_indices_complete=sorted(row['index'] for row in rows) == list(range(1801))))
    report = root / 'm4' / f'frozen-lua-compare-{name}.json'
    process = subprocess.run([sys.executable, 'scripts/compare_m3_sweeps.py',
        '--lua-raw', f'results/raw/m4-lua-{name}.candidates.jsonl',
        '--julia', str(new_dir / f'm4-julia-{name}-t1.jsonl'),
        '--out', str(report), '--stride', '1'], text=True,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    print(process.stdout, end='')
    lua_reports.append(dict(workload=name, report=str(report), passed=process.returncode == 0))

scenario = json.loads((root / 'scenario-parity.json').read_text())
passed = all(item['byte_identical'] and item['row_count'] == 1801 and
             item['all_completed'] and item['thread_identity'] and
             item['aim_indices_complete'] for item in comparisons)
passed = passed and all(item['passed'] for item in lua_reports)
passed = passed and scenario['summary']['all_ported_match']
result = dict(format='peggle.static_query_qualification', schema_version=1,
              passed=passed, julia_sweeps=comparisons,
              frozen_lua_comparisons=lua_reports,
              scenario_report=str(root / 'scenario-parity.json'),
              scenario_summary=scenario.get('summary', scenario.get('totals')))
output = root / 'sweep-qualification.json'
output.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
print(f'{output}: passed={passed}; {len(comparisons)} full sweeps')
raise SystemExit(0 if passed else 1)

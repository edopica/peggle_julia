from pathlib import Path
import csv,json,hashlib,tarfile
root=Path('tmp/static-query-optimization/retrieved')
source=root/'source'
base=source/'tmp/scoring-benchmarks/runs/deathstar-20261027-scoring-candidate'
cand=source/'tmp/static-query-benchmarks/runs/deathstar-20261027-static-query-candidate'
def record(p):
 m=json.loads((p/'manifest.json').read_text())
 r=next(csv.DictReader((p/'trials.csv').open()))
 h=source/m['artifacts']['canonical_gameplay_history']['path']
 assert hashlib.sha256(h.read_bytes()).hexdigest()==r['gameplay_sha256']
 return dict(run_id=m['run_id'],wall_seconds=float(r['wall_seconds']),candidates=int(r['candidates']),completed_matches=int(r['completed_matches']),candidates_per_second=float(r['candidates_per_second']),gameplay_sha256=r['gameplay_sha256']),m,h
b,bm,bh=record(base)
c,cm,ch=record(cand)
assert bh.read_bytes()==ch.read_bytes()
assert b['candidates']==c['candidates']==198110
assert b['completed_matches']==c['completed_matches']==10
assert (root/'exit-code').read_text().strip()=='0'
archive=Path('results/benchmarks/artifacts/deathstar-20261027-static-query-evidence.tar.gz')
report=dict(format='peggle.static_query_optimization_comparison',date='2026-10-27',host='deathstar',optimization='Reuse broad-phase static movement query per CCD window; prepare rectangle and annular bounding geometry; reuse rectangle radius during depenetration.',protocol=dict(games_per_variant=10,workers=1,julia_threads=1,repeats=1,warmup='full',base_seed=20261024,math_backend='system_libm',julia_version='1.12.6'),results=dict(baseline=b,candidate=c),comparison=dict(seconds_saved=b['wall_seconds']-c['wall_seconds'],elapsed_reduction_percent=100*(1-c['wall_seconds']/b['wall_seconds']),throughput_increase_percent=100*(b['wall_seconds']/c['wall_seconds']-1),speedup=b['wall_seconds']/c['wall_seconds'],gameplay_byte_identical=True),validation='Remote full Julia suite, reference verification before and after, independent artifact validation and compatibility comparison passed; canonical histories compared byte-for-byte. Local qualification is retained in the evidence archive.',limitations=['One measured trial per version; no repetition-based uncertainty estimate.','Historical baseline measured earlier on the same host, rather than interleaved with candidate.','Historical baseline manifest records be7856a dirty; all 78 fingerprinted simulator/harness source hashes equal fd760fc HEAD.'],evidence=dict(archive=str(archive),sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),size_bytes=archive.stat().st_size,extraction_validation_root='remote/source/',baseline_run_relative_to_extraction_root='tmp/scoring-benchmarks/runs/deathstar-20261027-scoring-candidate',candidate_run_relative_to_extraction_root='tmp/static-query-benchmarks/runs/deathstar-20261027-static-query-candidate',remote_comparison='remote/comparison.txt',local_qualification='local-qualification/'))
Path('results/analysis/static-query-optimization-2026-10-27.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report['comparison'],indent=2))

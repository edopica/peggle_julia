# Benchmark Run: `deathstar-20261028-dynamic-queue-10matches-02`

- **Benchmark**: `ribbon_1v1_campaign`
- **Workload**: `ribbon_1v1_10matches_1801aim`
- **Status**: `completed`
- **Timestamp (UTC)**: `2026-10-28T10:22:41Z`
- **Host**: `deathstar` (`AMD Ryzen Threadripper 2990WX 32-Core Processor`, 8 physical cores / 64 threads)
- **Runtime**: Julia `1.12.6` with `8` threads
- **Git revision**: `13743974222bda788b46f878b36eabbb1eeb0803` (dirty: `True`)
- **Harness fingerprint**: `a50b41f7176624bbfc25fb4cbf7a7fd6cf47fc00d726ab98654fcf50a82ef0a1`
- **Canonical gameplay hash**: `82b282ee176746817047e93d90755bedae81de07ed3b5ed876c9c336c8a96bb3`

## Worker Scaling

Summary metrics (medians across 1 repetition(s) per worker count):

| Workers | Campaign wall (s) | Completed matches/hour | Candidates/second | Speedup | Efficiency |
| ---: | ---: | ---: | ---: | ---: | ---: |
| 8 | 33.941 | 1060.7 | 5,836.9 | N/A | N/A |

### Wall Time by Repeat

| Workers | Repeat 1 (s) |
| ---: | ---: |
| 8 | 33.941 |

### Decision Latencies

| Workers | Mean decision (s) | p50 decision (s) | p95 decision (s) | Verification/output (s) |
| ---: | ---: | ---: | ---: | ---: |
| 8 | 1.427 | 0.644 | 5.293 | 0.2007 |

### Phase Durations

Values are summed worker wall durations across all matches:

| Workers | Simulation (s) | Candidate reset (s) | Selection (ms) | Actual shot (ms) | Checkpoint (ms) |
| ---: | ---: | ---: | ---: | ---: | ---: |
| 8 | 154.538 | 2.236 | 11.895 | 198.069 | 11.316 |

Process RSS after output ranges from **601.7 to 601.7 MiB**.
Cumulative process peak RSS is **721.2 MiB**.

## Match Results

Seeded matches (10 matches per campaign, 1 trials, all completed):

| Match | Player 1 score | Player 2 score | Winner | Turns | Termination |
| --- | ---: | ---: | ---: | ---: | --- |
| 1 | 128,460 | 146,250 | 2 | 7 | all_red_cleared |
| 2 | 248,840 | 149,963 | 1 | 10 | all_red_cleared |
| 3 | 140,770 | 325,590 | 2 | 8 | all_red_cleared |
| 4 | 233,364 | 117,240 | 1 | 9 | all_red_cleared |
| 5 | 210,860 | 308,470 | 2 | 6 | all_red_cleared |
| 6 | 839,728 | 71,650 | 1 | 11 | all_red_cleared |
| 7 | 31,533 | 7,608 | 1 | 20 | balls_exhausted |
| 8 | 104,580 | 289,420 | 2 | 8 | all_red_cleared |
| 9 | 19,643 | 273,763 | 2 | 12 | all_red_cleared |
| 10 | 308,970 | 39,771 | 1 | 19 | all_red_cleared |

## Workload Configuration

- Mode: `1v1`
- Matches: `10`
- Base seed: `20261024`
- Candidates per turn: `1801`
- Level: `fixtures/ribbon_waves/artifact/ribbon_waves.v1.json` (`073b426e66c948895a73a5a45b96b4a5538332c8db2d5b1318f245f8ffe6f86e`)
- Config: `campaigns/ribbon/config.v1.json` (`9de96e70851daa3d596c9cd3e28a1ad67705ec70e4afda5090e6868a2cad385c`)


## Artifacts

- Canonical gameplay history: [`tmp/dynamic-queue-benchmarks/histories/82b282ee176746817047e93d90755bedae81de07ed3b5ed876c9c336c8a96bb3.json`](<../../../../tmp/dynamic-queue-benchmarks/histories/82b282ee176746817047e93d90755bedae81de07ed3b5ed876c9c336c8a96bb3.json>)
- Full archive bundle: [`tmp/dynamic-queue-benchmarks/artifacts/deathstar-20261028-dynamic-queue-10matches-02.tar.gz`](<../../../../tmp/dynamic-queue-benchmarks/artifacts/deathstar-20261028-dynamic-queue-10matches-02.tar.gz>)

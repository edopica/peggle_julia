#!/usr/bin/env python3
"""Run analysis tooling on Python 3.10 without changing measured sources."""

import hashlib
from pathlib import Path
import runpy
import sys


if not hasattr(hashlib, "file_digest"):
    def file_digest(fileobj, digest, /, *, _bufsize=2**18):
        result = hashlib.new(digest) if isinstance(digest, str) else digest()
        while True:
            chunk = fileobj.read(_bufsize)
            if not chunk:
                return result
            result.update(chunk)

    hashlib.file_digest = file_digest


if len(sys.argv) < 2:
    raise SystemExit("usage: py310_runner.py SCRIPT [ARG ...]")

script = str(Path(sys.argv[1]).resolve())
sys.path.insert(0, str(Path(script).parent))
sys.argv = [script, *sys.argv[2:]]
runpy.run_path(script, run_name="__main__")

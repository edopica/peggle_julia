#!/usr/bin/env bash
set -euo pipefail
job=/home/picazio/projects/peggle-benchmarks/dynamic-queue-20261028-02
old=/home/picazio/projects/peggle-benchmarks/static-query-20261027
export PATH=/home/picazio/projects/peggle-benchmarks/tools/bin:$PATH
export JULIA_NUM_THREADS=3 JULIA_NUM_PRECOMPILE_TASKS=3
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 PEGGLE_MATH_BACKEND=system_libm
cd "$job"
test ! -e started-at
finish() {
  result=$?
  trap - EXIT
  echo "$result" > "$job/exit-code"
  date -u +%FT%TZ > "$job/finished-at"
  if test "$result" -eq 0; then echo completed; else echo failed; fi > "$job/status"
  exit "$result"
}
trap finish EXIT
date -u +%FT%TZ > started-at
echo preflight > status
uptime > host-before.txt
free -h >> host-before.txt
lscpu >> host-before.txt
ps -eo pid,pcpu,args --sort=-pcpu > processes-before.txt
julia --version > runtime.txt
cd source
git rev-parse HEAD > "$job/revision"
git status --porcelain > "$job/source-status.txt"
git diff --binary HEAD > "$job/source.patch"
julia --project=julia/PeggleSim -e 'using Pkg; Pkg.instantiate(); using PeggleSim' > "$job/instantiate.log" 2>&1
make verify > "$job/reference-before.log" 2>&1
julia --project=julia/PeggleSim -t 3 julia/PeggleSim/test/runtests.jl > "$job/simulator-tests.log" 2>&1
echo benchmarking > "$job/status"
uptime > "$job/trial-host-before.txt"
ps -eo pid,pcpu,args --sort=-pcpu > "$job/trial-processes-before.txt"
julia --project=julia/PeggleSim scripts/run_campaign_benchmark.jl \
  --run-id deathstar-20261028-dynamic-queue-10matches-02 \
  --benchmarks-dir tmp/dynamic-queue-benchmarks --allow-dirty \
  --worker-counts 8 --threads 8 --games 10 --repeats 1 \
  --warmup fast --mode 1v1 --base-seed 20261024 \
  --workload-id ribbon_1v1_10matches_1801aim > "$job/benchmark.log" 2>&1
echo postflight > "$job/status"
make verify > "$job/reference-after.log" 2>&1
python3 "$job/py310_runner.py" scripts/validate_benchmark.py \
  tmp/dynamic-queue-benchmarks/runs/deathstar-20261028-dynamic-queue-10matches-02 \
  --index tmp/dynamic-queue-benchmarks/index.csv > "$job/artifact-validation.log" 2>&1
# Compare retained canonical histories only; do not rerun or time a baseline.
python3 - "$old/source/tmp/static-query-benchmarks/histories" \
  tmp/dynamic-queue-benchmarks/histories > "$job/historical-identity.json" <<'PY'
import hashlib
import json
from pathlib import Path
import sys

previous, current = [list(Path(p).glob('*.json')) for p in sys.argv[1:]]
assert len(previous) == len(current) == 1, (previous, current)
a, b = previous[0].read_bytes(), current[0].read_bytes()
assert a == b, 'canonical gameplay differs from saved static-query campaign'
print(json.dumps({'byte_identical': True, 'gameplay_sha256': hashlib.sha256(b).hexdigest(),
                  'previous_history': str(previous[0]), 'current_history': str(current[0])}, indent=2))
PY
uptime > "$job/host-after.txt"
ps -eo pid,pcpu,args --sort=-pcpu > "$job/processes-after.txt"
